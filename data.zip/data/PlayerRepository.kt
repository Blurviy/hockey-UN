package com.hockey.data

import androidx.lifecycle.LiveData

class PlayerRepository(private val playersDao: PlayersDao) {

    val readAllData: LiveData<List<Player>> = playersDao.readAllData()

    suspend fun addPlayer(player: Player) {
        playersDao.addPlayer(player)
    }
}
