package com.hockey.data



import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "players_table")

data class Player(
    @PrimaryKey

    val id: Int =0,
    var email: String = "",
    var mobileNumber: String = ""
)